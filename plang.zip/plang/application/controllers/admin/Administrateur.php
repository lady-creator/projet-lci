<?php //session_start();
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrateur extends CI_Controller {
		function _contruct(){
			parent::_contruct();
			$this->sessionadmin();

		}
/* ################### page :: methode pour lister ################### */
	public function connexion()
	{
		if($_SESSION['id']!==NULL){
		$data['administrateurs'] = $this->M_administrateur->getAdministrateur();
		$data['titre'] = $this->lang->line('affich_admin');
		$this->load->view('administrateur/lister', $data);
			}else{
				redirect('index.php/admin/administrateur');
						}
			
	}
/* ################### page :: methode pour ajouter un admin ################### */
	public function ajouter(){
	if($_SESSION['id']!==NULL){
	

		$data['action']='admin/administrateur/ajouter';
		$data['submit'] = $this->lang->line('AJOUTER');
		$data['titr']=$this->lang->line('titr');
		$data['admins'] = $this->M_administrateur->getAdministrateur();
		$this->form_validation->set_rules('nomadmin', 'lang:nomadmin', 'strip_tags|trim|required');
		$this->form_validation->set_rules('prenomadmin', 'lang:prenomadmin', 'strip_tags|trim|required');
		$this->form_validation->set_rules('villeadmin', 'lang:villeadmin', 'trim|required');
		$this->form_validation->set_rules('sexeadmin', 'lang:sexeadmin', 'trim|required');
		$this->form_validation->set_rules('emailadmin', 'lang:emailadmin', 'trim|required|valid_email');
		$this->form_validation->set_rules('mdpadmin', 'lang:mdpadmin', 'trim|required||min_length[6]');
		$this->form_validation->set_rules('cmdp', 'lang:mdpadmin', 'trim|required|matches[mdpadmin]');
		$this->form_validation->set_rules('teladmin', 'lang:telephonecl', 'trim|required|min_length[9]|max_length[12]|numeric');
		if($this->form_validation->run())
		{
			foreach ($ros as $v) {
					$v->dateupdateadmin;
				}
			$mdp=$this->input->post('mdpadmin');
			$admin = array(
				'nomadmin' => strtoupper($this->input->post('nomadmin')),
				'prenomadmin' =>strtoupper( $this->input->post('prenomadmin')),
				'datenaissadmin' => $this->input->post('datenaissadmin'),
				'villeadmin' => strtoupper($this->input->post('villeadmin')),
				'sexeadmin' => strtoupper($this->input->post('sexeadmin')),
				'emailadmin' => $this->input->post('emailadmin'),
				'mdpadmin' => password_hash($mdp,PASSWORD_DEFAULT),
				'teladmin' => $this->input->post('teladmin'),
				'statutadmin' => $this->input->post('statutadmin'),
				'quatieradmin' => strtoupper($this->input->post('quatieradmin')),
				'datesaveadmin' => date('Y-m-d'),
				'dateupdateadmin' => $v->dateupdateadmin,
			);

			if($this->M_administrateur->addAdministrateur($admin))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/admin/administrateur/');
				
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/admin/administrateur/ajouter');
				echo "mo";
			}
		}
		$data['titre'] = $this->lang->line('ajouter_admin');
		$this->load->view('administrateur/ajouter', $data);
		}else{
				redirect('index.php/admin/administrateur');
						}
	}
/* ################### page :: methode pour modifier un admin ################### */	
	public function modifier($idadmin){
	if($_SESSION['id']!==NULL)
	{
		$data['titre'] = $this->lang->line('modif_admin');
		$data['submit'] = $this->lang->line('MODIFIER');
		$data['titr']=$this->lang->line('tit');
		$data['admins'] = $this->M_administrateur->getAdministrateur(array('idadmin'=>$idadmin));
		$data['action']='admin/administrateur/modifier/'.$idadmin;	
		$this->form_validation->set_rules('villeadmin', 'lang:villeadmin', 'required');
		$this->form_validation->set_rules('sexeadmin', 'lang:sexeadmin', 'required');
		$this->form_validation->set_rules('emailadmin', 'lang:emailadmin', 'required|valid_email');
		$this->form_validation->set_rules('mdpadmin', 'lang:mdpadmin', 'required|is_unique[administateur.mdpadmin]|min_length[6]');
		$this->form_validation->set_rules('cmdp', 'lang:mdpadmin', 'required|matches[mdpadmin]');
		$this->form_validation->set_rules('teladmin', 'lang:teladmin', 'required|min_length[9]');
		if($this->form_validation->run())
		{
			//$mdp=$this->input->post('mdpadmin');
			$admin = array(
				'idadmin'=>$idadmin,
				'nomadmin' => strtoupper($this->input->post('nomadmin')),
				'prenomadmin' =>strtoupper( $this->input->post('prenomadmin')),
				'datenaissadmin' => $this->input->post('datenaissadmin'),
				'villeadmin' => strtoupper($this->input->post('villeadmin')),
				'sexeadmin' => strtoupper($this->input->post('sexeadmin')),
				'emailadmin' => $this->input->post('emailadmin'),
				'mdpadmin' => password_hash($this->input->post('mdpadmin'),PASSWORD_DEFAULT),
				'teladmin' => $this->input->post('teladmin'),
				'statutadmin' => $this->input->post('statutadmin'),
				'quatieradmin' => strtoupper($this->input->post('quatieradmin')),
				'datesaveadmin' => date('Y-m-d'),
				'dateupdateadmin' => date('Y-m-d'),
			);
			if($this->M_administrateur->updateAdministrateur($admin))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/admin/administrateur/connexion');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				show_404();
			}
		}
		$this->load->view('administrateur/ajouter', $data);
		}else{
				redirect('index.php/admin/administrateur');
						}
	}
	
	public function index(){
		
		$emailadmin = $this->input->post('emailadmin');
		$mdpadmin =$this->input->post('mdpadmin');
		$data['titre']=$this->lang->line('connexion');
		$admin = $this->M_administrateur->getAdministrateur(array('emailadmin'=>$emailadmin));
		$this->form_validation->set_rules('emailadmin', 'lang:emailadmin', 'required|valid_email');
		$this->form_validation->set_rules('mdpadmin', 'lang:mdpadmin', 'required|min_length[6]');

		//print_r(password_verify($mdpadmin, $admin[0]->mdpadmin));
//print_r($admin);
		if($this->form_validation->run()){
			if(count($admin)){
				if (password_verify($mdpadmin, $admin[0]->mdpadmin)||($mdpadmin==$admin[0]->mdpadmin) ){
					$user=array(
				'id' => $admin[0]->idadmin,
				'username' => $admin[0]->nomadmin,
				'user' => $admin[0]->nomadmin,
				'email'=>$admin[0]->emailadmin,
				'tel'=>$admin[0]->teladmin,
				'name'=>$admin[0]->prenomadmin,
				'quartier'=>$admin[0]->quatieradmin,
				'statut'=>$admin[0]->statutadmin
				);
					//print_r($admin);
					$this->session->set_userdata ($user );
					if($_SESSION['id']!==NULL){
						redirect('index.php/admin/administrateur/connexion');
						}
			}else{

				echo "Vérifier votre mod de passe";
			}
			}else{
				echo "Vérifier votre adresse mail";
			}	
			}
	$this->load->view('administrateur/loginA',$data);
	}
	public function M_oublier(){
		$data['action']='admin/Administrateur/M_oublier';
		$data['titre']=$this->lang->line('connexion');
		$emailclt = $this->input->post('emailadmin');
		$this->form_validation->set_rules('emailadmin', 'lang:emailadmin', 'htmlspecialchars|trim|required|valid_email');
		$data['administrateur']=$admin=$this->M_administrateur->getadministrateur(array('emailadmin'=>$emailclt));

		if($this->form_validation->run()){
			if (count($administrateur)){
				$user=array(
				'id' => $admin[0]->idadmin,
				'username' => $admin[0]->nomadmin,
				'user' => $admin[0]->nomadmin,
				'email'=>$admin[0]->emailadmin,
				'tel'=>$admin[0]->teladmin,
				'name'=>$admin[0]->prenomadmin,
				'quartier'=>$admin[0]->quatieradmin,
				'statut'=>$admin[0]->statutadmin
				);
					$this->session->set_userdata ($user );
				echo "alert('jk')";
			}else{
				print_r('Verifiez votre adresse Mail ,vous n\'existez pas chez nous');
			}
		}
		$data['titre']=$this->lang->line('plang');

		$this->load->view('administrateur/u_admin',$data);
		
	
	}

	public function modif()
	{
		
		$this->form_validation->set_rules('mdp', 'lang:mdp', 'required|is_unique[administateur.mdpadmin]|min_length[6]');
		$this->form_validation->set_rules('cmdp', 'lang:mdpadmin', 'required|matches[mdpadmin]');
if($this->form_validation->run())
		{
			//$mdp=$this->input->post('mdpadmin');
			$admin = array(
				'idadmin'=>$idadmin,
				
				'mdpadmin' => password_hash($this->input->post('mdpadmin'),PASSWORD_DEFAULT),
				
				
				'dateupdateadmin' => date('Y-m-d'),
			);
			if($this->M_administrateur->updateAdministrateur($admin))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/admin/administrateur/connexion');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				show_404();
			}
		}
	}
/////////////// le chat entre le client et l'admin
	public function chat(){
		if($_SESSION['id']!==NULL){
		$data['titre']=$this->lang->line('connexion');
		$chat = $this->input->post('message');
		$this->form_validation->set_rules('message', 'lang:message', 'trim|htmlspecialchars|required');
		if($this->form_validation->run()){
			
			if(!empty($_SESSION['id'])){
				$ch=array(
					'message'=>$chat,
					'pseudo'=>$_SESSION['user'],
					'date'=>date('Y-m-d H:i:s')
					
				);
			}else{
				$ch=array(
					'message'=>$chat,
					'pseudo'=>'client',
					'date'=>date('Y-m-d H:i:s')
				);
			}
			if($this->M_administrateur->addChat($ch))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/admin/administrateur/chat');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				show_404();
			}
		}
		$data['administrateurs'] = $this->M_administrateur->getChat(array('limit'=>"5"));
		$this->load->view('administrateur/chat',$data);
		}else{
				redirect('index.php/admin/administrateur');
						}
	}
	///////////////La methode 
	public function getchat(){

	
		$data['administrateurs'] = $this->M_administrateur->getChat();
		
		$data['titre'] = $this->lang->line('affich_admin');

	}
	public function delete($id){
		if($_SESSION['id']!==NULL){
		$phot =$this->M_administrateur->getChat(array('id'=>$id));
		if($this->M_administrateur->deleteChat($id))
			{
			redirect('index.php/admin/administrateur/chat');
			} else {
				
				show_404();
			}
	$this->load->view('admin/administrateur/chat');
	}else{
		redirect('index.php/admin/administrateur');
						}

	}

///////////////////les deconnexion d'un user
	public function deconnexion(){

			$sess = array('tel','cart_contents', 'email','username','quartier','id','name','__ci_last_regenerate');
		$this->session->unset_userdata($sess);
		
		
		redirect('index.php/admin/administrateur/');
	}
}