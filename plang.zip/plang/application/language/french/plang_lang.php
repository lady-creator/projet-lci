<?php
/**
 * System messages translation for CodeIgniter(tm)
 * @author	CodeIgniter community
 * @copyright	Copyright (c) 2014-2019, British Columbia Institute of Technology (https://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	https://codeigniter.com
 */
defined('BASEPATH') OR exit('No direct script access allowed');

// Titre
$lang['ajouter_four']= "Ajouter un fournisseur ";
$lang['ajouter_client']= "INSCRIPTION ";
$lang['ajouter_cat']= "Ajouter une nouvelle catégorie";
$lang['ajouter_pro'] = "Ajouter un nouveau produit";
$lang['ajouter_admin']= "Add new administrator";
$lang['rmdp'] = "Confirmez votre mot de passe";
$lang['con']="j'ai lu les conditions générales de ventes et j'y adhère";
$lang['MODIFIER']="MODIFIER";
$lang['AJOUTER']="AJOUTER";
$lang['ajouter_admin'] = "ajouter un nouveau administateur";
$lang['livm'] = "A domicile";
$lang['livagence'] =" A l'agence";
$lang['modepayl']="A domicile";
$lang['modepayo']="orange money";
$lang['modepaym']="mobile money";
$lang['titrep']="AJOUTER LES PHOTOS AU MOINS 3 POUR UN PRODUIT
";
$lang['titr']="FORMULAIRE DE L'INSCRIPTION";
$lang['tit']="FORMULAIRE DE MODIFICATION";
$lang['affich_pro']="Afficher la liste des produits";
$lang['affich_clt']="Afficher la liste des clients";
$lang['affich_cmd']="afficher la liste des commandes";
$lang['affich_four']="Afficher la liste des fournisseurs";
$lang['affich_admin']="affiher la liste des administrateurs";
$lang['affich_cat']="Afficher la liste des categories";
$lang['modif_pro']="modifier le produit";
$lang['modif_clt']="modifier le client";
$lang['modif_cmd']="modifier la commandes";
$lang['modif_four']="modifier le fournisseur";
$lang['modif_admin']="modifier l'administrateur";
$lang['modif_cat']="modifier la categorie";
//traduction de la table categorie
$lang['nomcat'] = "Nom de la categorie";
$lang['ajouter_cat'] = "Ajouter une nouvelle catégorie";
$lang['parent'] = "La rubrique des catégories";

//traduction de la table produit
$lang['idpt'] = "Pdentifiant du  produit"	;
$lang['prixvtpt'] = "Prix de vente du produit *";
$lang['qtept'] = "Quantité du produit *";
$lang['photopt'] = "Photo du produit"	;
$lang['nomcat'] = "Nom du produit *"	;
$lang['idfour'] = "Identifiant du fournisseur"	;
$lang['datesavept'] = "Date d'enregistrement  du produit";
$lang['dateupdatept'] = "Date de modifcation  du produit";
$lang['descrppt'] = "Description du produit *";
$lang['prixapt'] = "Prix d'achat du produit";
$lang['monpt'] = "Nom du produit *";
$lang['originept'] = "Origine du produit";
$lang['marquept'] = "Marque du produit";
$lang['couleurpt'] = "Couleur du produit";
$lang['garantiept'] = "Garantie du produit";
$lang['typept'] = "Type du produit";
$lang['prixpromo'] = "Prix promotionnelle du produit";
$lang['statutpt'] = "statut du produit *"	;

//traduction de la table administateur
$lang['idadmin']     = "Identifiant de l'administateur";
$lang['nomadmin']    = "Nom de l'administateur *";
$lang['prenomadmin'] = "Prénom de l'administateur *";
$lang['datenaissadmin']= "Date de naissance de l'administateur *";
$lang['villeadmin']  = "Ville de l'administateur *";
$lang['sexeadmin']   = "Sexe de l'administateur *";
$lang['emailadmin']  = "Adresse email de l'administateur *";
$lang['mdpadmin']    = "mot de passe de l'administateur *";
$lang['teladmin']    = "téléphone de l'administateur *";
$lang['quatieradmin']= "Quartier de l'administateur *";
$lang['statutadmin'] = "Status de l'administateur *";
$lang['datesaveadmin']= "Date d'enregistremet de l'administateur *";
$lang['dateupdateadmin']= "Date de modifcation de l'administateur *";

//traduction de la table client		
$lang['sexeh'] = "Homme";
$lang['sexef'] = "Femme";
$lang['nomclt']="Nom *";
$lang['prenomclt']="Prénom  *";
$lang['datenaissclt']="Date de naissance *";
$lang['villeclient']="Ville du client *";
$lang['quartierclt']="Quartier *";
$lang['sexeclt']="Sexe du client *";
$lang['emailclt']="Adresse email *";
$lang['mdpclt']="mot de passe  *";
$lang['datesaveclt']="date d'enregistremet *";
$lang['dateupdateclt']="Date de modifcation *";
$lang['telclt']="Téléphone  *";
$lang['statutclt']="statut du client *";

//traduction de la commande
$lang['codecmd']=" le code de la commande ";   
$lang['idclient']="Identifiant du client ";   
$lang['datecmd']="Date à la quelle la commande a été passé ";   
$lang['statutcmd']="Statut de la commande ";  
$lang['ptcmd']="Prix de commande ";  
$lang['modliv']="Mode de livraison ";    
$lang['datepay']=" Date de payement ";   
$lang['modepay']="Mode de payement";  
$lang['adressedeliv ']="Adresse de livraison";  
$lang['nomcl']="Nom du client"; 
$lang['prenomcl']="Prénom ";   
$lang['telephonecl']="téléphone";   
$lang['emailcl']="Adresse email";  
$lang['villeliv']="Ville de livraison ";  
$lang['quatiercl']="Quartier de la livraison";  
$lang['adressedeliv'] = "Adresse de livraison";/*

*/
//traduction de la table constituant
$lang['qteconst']=" Quantité";
$lang['ptconst']="Prix totale";

//traduction de la fourisseur
$lang['idfour']="Identifiant du fournisseur *";
$lang['nomfour']="Nom du fournisseur *";
$lang['prenomfour']="Prénom du fournisseur *";
$lang['datenaissfour']="Date de naissance du fournisseur *";
$lang['villefour']="Ville du fournisseur *";
$lang['quartierfou']="Quartier du fournisseur *";
$lang['sexefour']="Sexe du fournisseur *";
$lang['emailfour']="Adresse email du fournisseur *";
$lang['mdpfour']="Mot de passe du fournisseur *";
$lang['datesavefour']="Date d'enregistrement du fournisseur *";
$lang['dateupdatefour']="Date de modifcation du fournisseur *";
$lang['telephonefour']="téléphone du fournisseur *";
$lang['statutfour']="statut du fournisseur *";