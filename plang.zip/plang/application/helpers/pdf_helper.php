<?php function tcpdf()
{
   
   // $this->helper('tcpdf/config/lang/fra.php');
   // $this->load->helper('tcpdf/tcpdf.php');
  // require_once('tcpdf/exemples/lang/fra.php');
   require_once('tcpdf/tcpdf.php');
} ?>