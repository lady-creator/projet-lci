-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 07 mai 2021 à 17:20
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `soins`
--

-- --------------------------------------------------------

--
-- Structure de la table `corps`
--

CREATE TABLE `corps` (
  `idCorps` int(11) NOT NULL,
  `ferm` int(11) NOT NULL COMMENT 'fermete',
  `verg` int(11) DEFAULT NULL COMMENT 'vergeture',
  `cell` int(11) DEFAULT NULL COMMENT 'cellulite',
  `ne` int(11) DEFAULT NULL COMMENT 'necessite d''epilation',
  `etm` varchar(45) DEFAULT NULL COMMENT 'eteat des mains',
  `etp` varchar(45) DEFAULT NULL COMMENT 'etat des pieds',
  `etlp` varchar(45) DEFAULT NULL COMMENT 'etat de la poitrine',
  `descorp` longtext NOT NULL,
  `desmain` longtext DEFAULT NULL,
  `despied` longtext DEFAULT NULL,
  `despoit` longtext DEFAULT NULL,
  `Pidpers` int(11) NOT NULL,
  `statut` varchar(15) NOT NULL,
  `datesave` date NOT NULL,
  `dateupdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `corps`
--

INSERT INTO `corps` (`idCorps`, `ferm`, `verg`, `cell`, `ne`, `etm`, `etp`, `etlp`, `descorp`, `desmain`, `despied`, `despoit`, `Pidpers`, `statut`, `datesave`, `dateupdate`) VALUES
(1, 1, 0, 1, 5, '4', '6', '4', 'n,v', 'vbn', 'nbvn', 'nb', 2, 'initial', '2021-05-06', '2021-05-06'),
(2, 5, 4, 4, 7, '8', '6', '8', 'avec evolution', 'pieds bien', 'et oui', 'ou ii', 1, 'initial', '2021-05-07', '2021-05-07'),
(3, 1, 1, 1, 1, '1', '1', '1', 'oui', 'non', 'non', 'non', 3, 'initial', '2021-05-07', '2021-05-07');

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

CREATE TABLE `personne` (
  `idpers` int(11) NOT NULL,
  `nomp` varchar(75) NOT NULL,
  `age` varchar(45) NOT NULL,
  `sexe` varchar(20) NOT NULL,
  `prof` varchar(45) NOT NULL,
  `tel` varchar(45) NOT NULL,
  `adr` varchar(45) NOT NULL,
  `mail` varchar(75) NOT NULL,
  `etatc` varchar(75) NOT NULL,
  `personnecol` varchar(75) DEFAULT NULL,
  `aller` varchar(75) DEFAULT NULL,
  `gest` varchar(75) DEFAULT NULL,
  `frem` varchar(75) DEFAULT NULL,
  `mpc` varchar(205) DEFAULT NULL COMMENT 'maladie de la peau connue',
  `tc` varchar(45) DEFAULT NULL COMMENT 'traitement en cours',
  `cu` varchar(45) DEFAULT NULL COMMENT 'cosmetique utilise',
  `sm` varchar(75) DEFAULT NULL COMMENT 'soin maison',
  `tabac2` varchar(45) DEFAULT NULL,
  `alcool` varchar(45) DEFAULT NULL,
  `imc` varchar(45) DEFAULT NULL,
  `hobbies` varchar(45) DEFAULT NULL,
  `statut` enum('actif','passif','off') DEFAULT NULL,
  `datesave` date NOT NULL,
  `dateupdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `personne`
--

INSERT INTO `personne` (`idpers`, `nomp`, `age`, `sexe`, `prof`, `tel`, `adr`, `mail`, `etatc`, `personnecol`, `aller`, `gest`, `frem`, `mpc`, `tc`, `cu`, `sm`, `tabac2`, `alcool`, `imc`, `hobbies`, `statut`, `datesave`, `dateupdate`) VALUES
(1, 'dariska', '152', '45', 'etudiant', '67963526', 'douala', 'flo@dd.com', 'celiba', 'p', 'allergie', 'oui', 'gestion', 'manger gras', 'et vous', 'un peur ', 'pas vraiment', 'toujpous', 'oui', 'vrai', 'faux', 'actif', '0000-00-00', '0000-00-00'),
(2, 'bgfc', '2', 'M', 'vvvvvvvvvvvvc', '679909454', 'c', 'vc', 'cv', NULL, '', '', '', 'vc', 'vc', 'vc', '', 'cv', 'vc', 'cv', 'cv', 'actif', '2021-05-06', '2021-05-06'),
(3, 'bgfc', '45', 'F', 'vvvvvvvvvvvvc', '679909454', 'c', 'flor@gmail.com', 'cv', NULL, 'aller', 'oui', 'non', 'vc', 'vc', 'vc', 'rien', 'cv', 'vc', 'cv', 'cv', 'actif', '2021-05-06', '2021-05-06');

-- --------------------------------------------------------

--
-- Structure de la table `visage`
--

CREATE TABLE `visage` (
  `idv` int(11) NOT NULL,
  `ep` varchar(45) DEFAULT NULL COMMENT 'etat de la peau',
  `bril` varchar(45) DEFAULT NULL,
  `gp` varchar(45) DEFAULT NULL COMMENT 'grain de peau',
  `ct` varchar(45) NOT NULL COMMENT 'couleur du teint',
  `hydra` int(11) DEFAULT NULL COMMENT 'hydratation',
  `rr` varchar(45) DEFAULT NULL COMMENT 'ride ridules',
  `imper` varchar(45) DEFAULT NULL COMMENT 'imperfection',
  `tp` varchar(45) DEFAULT NULL COMMENT 'types de peau',
  `comed` varchar(45) DEFAULT NULL COMMENT 'comedons',
  `pp` varchar(45) DEFAULT NULL COMMENT 'papules ',
  `etp` varchar(45) DEFAULT NULL COMMENT 'etat des pores',
  `cs` int(11) DEFAULT NULL COMMENT 'circulation sanguine',
  `sourci` varchar(45) DEFAULT NULL,
  `duvet` varchar(45) DEFAULT NULL,
  `autres` varchar(45) DEFAULT NULL,
  `descrit` longtext NOT NULL,
  `statut` varchar(45) DEFAULT NULL,
  `Pidpers` int(11) NOT NULL,
  `datesave` date NOT NULL,
  `dateupdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `visage`
--

INSERT INTO `visage` (`idv`, `ep`, `bril`, `gp`, `ct`, `hydra`, `rr`, `imper`, `tp`, `comed`, `pp`, `etp`, `cs`, `sourci`, `duvet`, `autres`, `descrit`, `statut`, `Pidpers`, `datesave`, `dateupdate`) VALUES
(1, 'dfg', 'dfg', 'fdgf', 'dfgf', 56, 'dfg', 'cxv', NULL, 'fg', 'fgg', 'dfg', 0, 'fgf', 'fgf', NULL, 'cvxc', 'initial', 3, '2021-05-06', '2021-05-06'),
(3, '4', '4', '4', '4', 4, '4', '4', '', '4', '', '4', 4, '4', '4', '', 'yfjh', 'initial', 2, '2021-05-06', '2021-05-07'),
(4, 'dd', 'dfgf', 'hj', 'fgj', 7, 'h', 'h', 'rr', 'rr', 'hg', 'hg', 74, 'dd', 'rr', 'rr', 'fg', 'initial', 1, '2021-05-06', '2021-05-06');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `corps`
--
ALTER TABLE `corps`
  ADD PRIMARY KEY (`idCorps`),
  ADD KEY `fk_Corps_Personne1_idx` (`Pidpers`);

--
-- Index pour la table `personne`
--
ALTER TABLE `personne`
  ADD PRIMARY KEY (`idpers`);

--
-- Index pour la table `visage`
--
ALTER TABLE `visage`
  ADD PRIMARY KEY (`idv`),
  ADD KEY `fk_Visage_Personne_idx` (`Pidpers`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `corps`
--
ALTER TABLE `corps`
  MODIFY `idCorps` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `personne`
--
ALTER TABLE `personne`
  MODIFY `idpers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `visage`
--
ALTER TABLE `visage`
  MODIFY `idv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `corps`
--
ALTER TABLE `corps`
  ADD CONSTRAINT `fk_Corps_Personne1` FOREIGN KEY (`Pidpers`) REFERENCES `personne` (`idpers`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `visage`
--
ALTER TABLE `visage`
  ADD CONSTRAINT `fk_Visage_Personne` FOREIGN KEY (`Pidpers`) REFERENCES `personne` (`idpers`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
