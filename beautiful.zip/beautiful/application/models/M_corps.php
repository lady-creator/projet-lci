<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class M_corps extends CI_Model {
		public function addcorps($options)
		{
				$this->db->insert('corps', $options);
			//Si le champs est ue cle auto increment
			//return $this->db->insert_id();
			// si non auto increment
			return $this->db->affected_rows();

  }

  public function geta($limit,$start)
  {    
    $this->db->select('*');
    $this->db->from('corps');
    $this->db->limit($limit, $start);
    $query = $this->db->get()->result();   
    return $query;
  }
  

  public function getcorps($options=NULL){
 
 if(isset($options['nom'])) $this->db->where('nom', $options['nom']);
  if(isset($options['idCorps'])) $this->db->where('idCorps', $options['idCorps']);
  if(isset($options['Pidpers'])) $this->db->where('Pidpers', $options['Pidpers']);
  if(isset($options['statut'])) $this->db->where('statut', $options['statut']);
  
  $query = $this->db->get('corps');
      return $query->result();
}
public function updatecorps($options)
    { 
      if(isset($options['ferm'])) $this->db->set('ferm', $options['ferm']);
  if(isset($options['login'])) $this->db->set('login', $options['login']);
  if(isset($options['date_naiss'])) $this->db->set('date_naiss', $options['date_naiss']);
  if(isset($options['ne'])) $this->db->set('ne', $options['ne']);
  if(isset($options['verg'])) $this->db->set('verg', $options['verg']);
  if(isset($options['statut'])) $this->db->set('statut', $options['statut']);
 
  if(isset($options['ville'])) $this->db->set('ville', $options['ville']);
      $this->db->where('idCorps', $options['idCorps']);
 $this->db->update('corps', $options);
      return $this->db->insert_id();
    }

    public function delcorps($id ){
      if(isset($options['ferm'])) $this->db->where('ferm', $options['ferm']);
      if(isset($options['cell'])) $this->db->where('cell', $options['cell']);
        
      if(isset($options['datesave']))$this->db->where('datesave',$options['datesave']);
          

      $this->db->where('idCorps',$id);
      $query = $this->db->delete('corps');  
      return $this->db->insert_id();
    }
  }
