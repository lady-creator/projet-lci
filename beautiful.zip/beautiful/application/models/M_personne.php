	<?php defined('BASEPATH') OR exit('No direct script access allowed');
  class M_personne extends CI_Model {

		public function addpersonne($options)
		{
				$this->db->insert('personne', $options);
			//Si le champs est ue cle auto increment
			//return $this->db->insert_id();
			// si non auto increment
			return $this->db->affected_rows();

  }

  public function geta($limit,$start)
  {    
    $this->db->select('*');
    $this->db->from('personne');
    $this->db->limit($limit, $start);
    $query = $this->db->get()->result();   
    return $query;
  }
  

  public function getpersonne($options=NULL){
 
 if(isset($options['nom'])) $this->db->where('nom', $options['nom']);
  if(isset($options['idpers'])) $this->db->where('idpers', $options['idpers']);
  if(isset($options['login'])) $this->db->where('login', $options['login']);
  if(isset($options['date_naiss'])) $this->db->where('date_naiss', $options['date_naiss']);
  if(isset($options['sexe'])) $this->db->where('sexe', $options['sexe']);
  if(isset($options['n_tel'])) $this->db->where('n_tel', $options['n_tel']);
  if(isset($options['statut'])) $this->db->where('statut', $options['statut']);
 
  if(isset($options['ville'])) $this->db->where('ville', $options['ville']);
  $query = $this->db->get('personne');
      return $query->result();
}
public function updatepersonne($options)
    { 
      if(isset($options['nom'])) $this->db->set('nom', $options['nom']);
  if(isset($options['login'])) $this->db->set('login', $options['login']);
  if(isset($options['date_naiss'])) $this->db->set('date_naiss', $options['date_naiss']);
  if(isset($options['sexe'])) $this->db->set('sexe', $options['sexe']);
  if(isset($options['n_tel'])) $this->db->set('n_tel', $options['n_tel']);
  if(isset($options['statut'])) $this->db->set('statut', $options['statut']);
 
  if(isset($options['ville'])) $this->db->set('ville', $options['ville']);
      $this->db->where('ida', $options['ida']);
 $this->db->update('personne', $options);
      return $this->db->insert_id();
    }

    public function deletepersonne($id ){
      if(isset($options['nom'])) $this->db->where('nom', $options['nom']);
      if(isset($options['tel'])) $this->db->where('tel', $options['tel']);
        
      if(isset($options['datesave']))$this->db->where('datesave',$options['datesave']);
          

      $this->db->where('ida',$id);
      $query = $this->db->delete('personne');  
      return $this->db->insert_id();
    }
  }
