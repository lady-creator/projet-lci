<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Visage extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('about');
	}
	
	public function affichevisage($f=NULL){

		//if(!empty($_SESSION['ida'])){
				$data['titre'] = 'camion';
				$this->load->library('pagination');
				$lvisage=$this->M_visage->getvisage();
				$sess=array(
				
				'nom'=>$lvisage[0]->nomp,
				'statut'=>$lvisage[0]->statut,
				'ida'=>$lvisage[0]->idpers
				);
$this->session->set_userdata($sess);

			 $config['base_url']=site_url('Welcome/listevisage');
				$config['per_page']=10;
				$config['reuse_query_string'] = TRUE;
				$config['total_rows']=count($this->M_visage->getvisage());
					$config['full_tag_open'] = '<div class="pagination uk-align-center uk-width-1-4" ">';
						$config['full_tag_close'] = '</div>';
						
						$config['first_link'] = 'First';
						$config['first_tag_open'] = '<button class="firstlink" style="border:2px solid green; background-color:white;  font-size:18px;">';
						$config['first_tag_close'] = '</button>';
						
						$config['last_link'] = 'Last';
						$config['last_tag_open'] = '<button class="lastlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['last_tag_close'] = '</button>';
						
						$config['next_link'] = 'Next';
						$config['next_tag_open'] = '<button class="nextlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['next_tag_close'] = '</button>';

						$config['prev_link'] = 'Prev Page';
						$config['prev_tag_open'] = '<button class="prevlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['prev_tag_close'] = '</button>';

						$config['cur_tag_open'] = '<button class="curlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['cur_tag_close'] = '</button>';

						$config['num_tag_open'] = '<button class="numlink" style="border:2px solid green; background-color:white; font-size:18px;">';
						$config['num_tag_close'] = '</button>';
				$data['visage']=$this->M_visage->getvisage();
				$this->pagination->initialize($config);
				$login=$this->input->get('login');	
				/*if(empty($login)){
							$data['visage']=$this->M_admin->geta($config['per_page'],$f);
				}else{
					$data['admin']=$this->M_admin->getadmin(array('login'=>$login));
				}

					$data['links']=$this->pagination->create_links();
		   		 $this->load->view('listeadmin', $data);
		    }else{
		    	redirect('');
		    }*/
//	}
		    $data['links']=$this->pagination->create_links();
		    $r=$data['visage']=$this->M_visage->geta($config['per_page'],$f);
		    
			$this->load->view('affvisage', $data);
		}


		/////////////////////insere un nouveau client
		public function newvisage($new){
		$data['titre'] = 'fiche';
		$data['action']='visage/newvisage/'.$new;
		$data['submit'] = 'ENVOYER';
		$data['couleur'] = 'uk-button-secondary';
		$data['tit']='creer un nouveau administrateur';
		
		//$data['admins'] = $this->M_admin->getadmin();
		$this->form_validation->set_rules('ep', 'lang:ETAT DE LA PEAU', 'strip_tags|trim|required|integer');
		
		$this->form_validation->set_rules('comed', 'lang:COMEDONS', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('bril', 'lang:brillance', 'trim|required|integer');
		$this->form_validation->set_rules('hydra', 'lang:hydra', 'trim|required|integer');
		$this->form_validation->set_rules('rr', 'lang:rides/ridules', 'trim|required|integer');
		$this->form_validation->set_rules('descrit', 'lang:diagnostic et prescription', 'strip_tags|trim|required');
		$this->form_validation->set_rules('ct', 'lang:couleur de tient', 'trim|required|integer');
		$this->form_validation->set_rules('cs', 'lang:circulation sanguine', 'trim|required|integer');
		$this->form_validation->set_rules('rr', 'lang:rr', 'trim|required|integer');
		$this->form_validation->set_rules('imper', 'lang:imperfection', 'trim|required|integer');
			if (count($this->M_visage->getvisage(array('Pidpers'=>$new)))) {
				$statut='evolution';
			}else{
				$statut='initial';
			}
			if($this->form_validation->run())
					{					
			$visage = array(
				'Pidpers'=>$new,
				'ep' => $this->input->post('ep'),
				'gp' => $this->input->post('gp'),
				'statut' => $statut,
				'ct' => $this->input->post('ct'),
				'tp' => $this->input->post('tp'),
				'comed' => $this->input->post('comed'),
				'hydra' =>$this->input->post('hydra'),
				'bril' => $this->input->post('bril'),
				'pp' => $this->input->post('pp'),
				'descrit' => $this->input->post('descrit'),
				'etp' => $this->input->post('etp'),
				'cs' => $this->input->post('cs'),
				'sourci' => $this->input->post('sourci'),
				
				'imper' => $this->input->post('imper'),
				'duvet' => $this->input->post('duvet'),
				'autres' => $this->input->post('autres'),
				'rr' => $this->input->post('rr'),
				'datesave' => date('Y-m-d'),
				'dateupdate' =>date('Y-m-d')
			);
			
			if($this->M_visage->addvisage($visage))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					redirect('index.php/Welcome/fichesoins/'.$new);
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					redirect('index.php/visage/insere_visage');
				}
			
		}
		
		$this->load->view('insere_visage', $data);

	}

	public function updatevisage($m2){
		$data['titre'] = 'visage';
		$data['submit'] = 'Modifier';
		$data['couleur'] = 'uk-button-danger';
		$data['action']='visage/updatevisage/'.$m2;
			$l=$this->M_visage->getvisage(array('idv'=>$m2));
			//print_r($l);	
		$this->form_validation->set_rules('ep', 'lang:ETAT DE LA PEAU', 'strip_tags|trim|required|integer');
		
		$this->form_validation->set_rules('comed', 'lang:COMEDONS', 'strip_tags|trim|required|integer');
		$this->form_validation->set_rules('bril', 'lang:brillance', 'trim|required|integer');
		$this->form_validation->set_rules('hydra', 'lang:hydra', 'trim|required|integer');
		$this->form_validation->set_rules('rr', 'lang:rides/ridules', 'trim|required|integer');
		$this->form_validation->set_rules('descrit', 'lang:diagnostic et prescription', 'strip_tags|trim|required');
		$this->form_validation->set_rules('ct', 'lang:couleur de tient', 'trim|required|integer');
		$this->form_validation->set_rules('cs', 'lang:circulation sanguine', 'trim|required|integer');
		$this->form_validation->set_rules('rr', 'lang:rr', 'trim|required|integer');
		$this->form_validation->set_rules('imper', 'lang:imperfection', 'trim|required|integer');
		if($this->form_validation->run())
		{
			$visag = array(
				//'Pidipers' => $m2,
				'idv'=>$m2,
				'ep' => $this->input->post('ep'),
				'gp' => $this->input->post('gp'),
				'ct' => $this->input->post('ct'),
				'tp' => $this->input->post('tp'),
				'comed' => $this->input->post('comed'),
				'hydra' =>$this->input->post('hydra'),
				'bril' => $this->input->post('bril'),
				'pp' => $this->input->post('pp'),
				'descrit' => $this->input->post('descrit'),
				'etp' => $this->input->post('etp'),
				'cs' => $this->input->post('cs'),
				'sourci' => $this->input->post('sourci'),	
				'imper' => $this->input->post('imper'),
				'duvet' => $this->input->post('duvet'),
				'autres' => $this->input->post('autres'),
				'rr' => $this->input->post('rr'),
				'dateupdate' =>date('Y-m-d')
			);
			//print_r($visag);
			if($this->M_visage->updatevisage($visag))
				{
					$this->session->set_flashdata('success', 'information enregistrée');
					//redirect('index.php/visage/updatevisage/'.$l[0]->Pidpers);
				} else {
					$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
					
					redirect('index.php/Welcome/fichesoins/'.$l[0]->Pidpers);
					
				}
			
		}
		$this->load->view('insere_visage', $data);
	}

	public function delvisage($idp){
		
		//$phot =$this->M_admim->getPhoto(array('ida'=>$idp));
			$l=$this->M_visage->getvisage(array('idv'=>$idp));
		if($this->M_visage->delvisage($idp))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('index.php/Welcome/fichesoins/'..$l[0]->Pidpers);
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('index.php/Welcome/fichesoins/'..$l[0]->Pidpers);
			}
		//$this->load->view('chauf/produit/');
		
	}

}
