 <div class="bg-6">
        <div class="container_24">
             <div class="grid_24">
                <div class="line"></div>
                <div class="call">
                    <span>Call us free:</span>
                    <span>+237 6 72 17 12
                    <strong>+237 6 72 17 12</strong></span>
                </div>
             </div>
             <div class="clear"></div>
        </div>
       </div>      
    </section> 
</div>
<!--==============================footer=================================-->
  <footer>
      <p>© 2021  LCI<br>
      
  </footer>        